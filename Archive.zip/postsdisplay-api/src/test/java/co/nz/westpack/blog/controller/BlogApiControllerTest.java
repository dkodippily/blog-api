package co.nz.westpack.blog.controller;

import co.nz.westpack.blog.model.Comment;
import co.nz.westpack.blog.model.Post;
import co.nz.westpack.blog.service.BlogApiService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import java.util.ArrayList;
import java.util.Arrays;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * @author Dayan Kodippily - 1/12/20
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebMvcTest(value = BlogApiController.class)
public class BlogApiControllerTest {

    @MockBean
    BlogApiService blogApiService;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    ObjectMapper objectMapper;


    @Test
    public void findPostAndCommentsByPost() throws Exception{
        Post post = Post.builder().id(1).userId(1).
                title("test").body("test body").
                comments(new ArrayList<>(Arrays.asList(Comment.builder().id(1).postId(1).email("test@test.com").
                        body("comment body").build())))
                .build();


        when(blogApiService.findPostAndCommentsByPost(1)).thenReturn(post);

        mockMvc.perform(get("/api/posts/1").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("id", is(1)))
                .andExpect(jsonPath("title", is("test")))
                .andExpect(jsonPath("body", is("test body")))
                .andExpect(jsonPath("comments", hasSize(1)));


    }

   /* @Ignore
    @Test
    void findAllPostsWithComments() {
    }*/
}