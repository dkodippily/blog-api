package co.nz.westpack.blog.service;

import co.nz.westpack.blog.exception.InvalidParameterException;
import co.nz.westpack.blog.exception.NoPostsFoundException;
import co.nz.westpack.blog.model.Post;

import java.util.List;

/**
 * @author Dayan Kodippily - 1/12/20
 */

public interface BlogApiService {


    public List<Post> findAllPostsWithComments() throws NoPostsFoundException;

    public Post findPostAndCommentsByPost(Integer postId) throws InvalidParameterException, NoPostsFoundException;


}
