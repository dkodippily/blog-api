package co.nz.westpack.blog.common;

/**
 * @author Dayan Kodippily - 1/12/20
 */


public class Constants {

    //Endpoints
    public static final String API_DISPLAY_POST_RECORD_WITH_COMMENTS_BY_ID = "/posts/{id}";
    public static final String API_DISPLAY_POSTS_ALL_RECORDS_WITH_COMMENTS = "/posts";
    public static final String API_DISPLAY_POSTS = "/api";

    public static final String ALL_POSTS_ENDPOINT = "https://jsonplaceholder.typicode.com/posts/";
    public static final String COMMENTS_BY_POST_ID_ENDPOINT = "https://jsonplaceholder.typicode.com/posts/{postId}/comments";
    public static final String POST_BY_ID_ENDPOINT = "https://jsonplaceholder.typicode.com/posts/{postId}";

    public static final String CLIENT_APP_ENDPOINT = "http://localhost:3000";

    //Errors
    public static final String POSTS_NOT_FOUND_ERROR = "Posts not found";
    public static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
    public static final String NO_POST_FOUND_FOR_ID_ERROR = "No posts found for the given Id";
    public static final String INVALID_PARAMETER_ERROR = "Invalid input parameter";
    public static final String NULL_RESPONSE_ERROR = "No posts found, null response from base GET endpoint";
}
