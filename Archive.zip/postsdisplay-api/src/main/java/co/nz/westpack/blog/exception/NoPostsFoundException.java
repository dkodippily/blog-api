package co.nz.westpack.blog.exception;

/**
 * @author Dayan Kodippily - 1/12/20
 */


public class NoPostsFoundException extends  Exception{

    public NoPostsFoundException(String message){super(message);}
}
