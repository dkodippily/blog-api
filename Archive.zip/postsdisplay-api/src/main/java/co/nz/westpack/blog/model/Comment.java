package co.nz.westpack.blog.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Dayan Kodippily - 1/12/20
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Comment {

    @JsonProperty("id")
    private Integer id;

    @JsonProperty("postId")
    private Integer postId;

    @JsonProperty("name")
    private String name;

    @JsonProperty("email")
    private String email;

    @JsonProperty("body")
    private String body;
}
