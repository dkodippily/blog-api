package co.nz.westpack.blog.exception;

/**
 * @author Dayan Kodippily - 1/12/20
 */


public class InvalidParameterException extends Exception{

    public InvalidParameterException(String message){super(message);}
}
