package co.nz.westpack.blog.service.impl;

import co.nz.westpack.blog.common.Constants;
import co.nz.westpack.blog.exception.InvalidParameterException;
import co.nz.westpack.blog.exception.NoPostsFoundException;
import co.nz.westpack.blog.model.Comment;
import co.nz.westpack.blog.model.Post;
import co.nz.westpack.blog.service.BlogApiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Dayan Kodippily - 1/12/20
 */


@Service
public class BlogApiServiceImpl implements BlogApiService {

    private final RestTemplate restTemplate;

    @Autowired
    BlogApiServiceImpl(RestTemplate restTemplate){
        this.restTemplate = restTemplate;
    }

    /**
     * Returns all posts with associated comments
     * @return
     */
    @Override
    public List<Post> findAllPostsWithComments() throws NoPostsFoundException {

        List<Post> result = new ArrayList<>();
        ResponseEntity<Post[]> response = restTemplate.getForEntity(Constants.ALL_POSTS_ENDPOINT, Post[].class);
        if(response == null){
            throw new NoPostsFoundException(Constants.NULL_RESPONSE_ERROR);
        }
        //Post[] posts = response.getBody();

        Post[] posts = Arrays.asList(response.getBody()).stream().limit(20).collect(Collectors.toList()).toArray(new Post[20]);

        if(posts == null || posts.length == 0){
            throw new NoPostsFoundException(Constants.POSTS_NOT_FOUND_ERROR);
        }

        for(Post post : posts){
            Integer postId = post.getId();
            ResponseEntity<Comment[]> commentsResponse = restTemplate.getForEntity(Constants.COMMENTS_BY_POST_ID_ENDPOINT, Comment[].class, postId);
            Comment[] comments = commentsResponse.getBody();
            List<Comment> commentList = Arrays.asList(comments);
            post.setComments(commentList);
            result.add(post);
        }

        return result;
    }

    /**
     * Returns a specific post with comments by post Id
     * @param postId
     * @return
     */
    @Override
    public Post findPostAndCommentsByPost(Integer postId) throws InvalidParameterException, NoPostsFoundException{

        if(postId == null){
          throw new InvalidParameterException(Constants.INVALID_PARAMETER_ERROR);
        }

        ResponseEntity<Post> response = restTemplate.getForEntity(Constants.POST_BY_ID_ENDPOINT,Post.class, postId);

        if(response == null){
            throw new NoPostsFoundException(Constants.NO_POST_FOUND_FOR_ID_ERROR);
        }

        Post post = response.getBody();
        ResponseEntity<Comment[]> commentsResponse = restTemplate.getForEntity(Constants.COMMENTS_BY_POST_ID_ENDPOINT, Comment[].class, postId);
        Comment[] comments = commentsResponse.getBody();
        List<Comment> commentList = Arrays.asList(comments);
        post.setComments(commentList);
        return post;
    }

}
