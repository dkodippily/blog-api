package co.nz.westpack.blog.exception;

import lombok.Data;
import org.springframework.http.HttpStatus;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

/**
 * @author Dayan Kodippily - 1/12/20
 */

@Data
public class ApiError {

    private Integer status;
    private String message;
    private LocalDateTime timestamp;
    private List<String> errors;

    public ApiError(HttpStatus status, String message, List<String> errors) {
        super();
        this.timestamp = LocalDateTime.now();
        this.status = status.value();
        this.message = message;
        this.errors = errors;

    }

    public ApiError(HttpStatus status, String message, String error) {
        super();
        this.timestamp = LocalDateTime.now();
        this.status = status.value();
        this.message = message;
        errors = Arrays.asList(error);
    }
}
