package co.nz.westpack.blog.controller;

import co.nz.westpack.blog.common.Constants;
import co.nz.westpack.blog.exception.InvalidParameterException;
import co.nz.westpack.blog.exception.NoPostsFoundException;
import co.nz.westpack.blog.model.Post;
import co.nz.westpack.blog.service.BlogApiService;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author Dayan Kodippily - 1/12/20
 */

@ApiOperation(value = "Blog API", hidden = true)
@CrossOrigin(origins = Constants.CLIENT_APP_ENDPOINT,maxAge = 3600)
@RestController
@RequestMapping(Constants.API_DISPLAY_POSTS)
public class BlogApiController {

    private static final Logger logger = LoggerFactory.getLogger(BlogApiController.class);

    private final BlogApiService blogApiService;

    @Autowired
    public BlogApiController(BlogApiService blogApiService) {
        this.blogApiService = blogApiService;
    }


    /**
     * Fetch all posts with comments
     * @return
     * @throws Exception
     */

    @ApiOperation(value = "Fetch all posts with comments")
    @GetMapping(value = {"", Constants.API_DISPLAY_POSTS_ALL_RECORDS_WITH_COMMENTS})
    public ResponseEntity<List<Post>> findAllPostsWithComments() throws NoPostsFoundException {

        logger.info("calling findAllPostsWithComments :: fetching all posts with comments");

        List<Post> listOfPostsWithComments = blogApiService.findAllPostsWithComments();
        if(listOfPostsWithComments == null || listOfPostsWithComments.size() == 0){
            throw new NoPostsFoundException("No posts found");
        }

        return new ResponseEntity<>(blogApiService.findAllPostsWithComments(), HttpStatus.OK);
    }


    /**
     * Fetch a post with comments by post ID
     * @param id
     * @return
     * @throws Exception
     */

    @ApiOperation(value = "Fetch a post with comments by post ID")
    @GetMapping(value = {"", Constants.API_DISPLAY_POST_RECORD_WITH_COMMENTS_BY_ID})
    public ResponseEntity<Post> findPostAndCommentsByPost(@PathVariable Integer id) throws InvalidParameterException, NoPostsFoundException {

        logger.info("calling findPostAndCommentsByPost :: fetching posts with comments by post Id " + id);

        if(id == null){
            throw new InvalidParameterException("Invalid parameter, null Id");
        }

        Post postWithComment = blogApiService.findPostAndCommentsByPost(id);

        if(postWithComment == null){
            throw new NoPostsFoundException("No posts found");
        }

        return new ResponseEntity<>(blogApiService.findPostAndCommentsByPost(id), HttpStatus.OK);
    }

}
