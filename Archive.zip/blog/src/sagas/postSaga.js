import { call, put } from "redux-saga/effects";
import { fetchPostRequest } from "../api";
import {
    postRequestSuccess,
    postRequestFailed,
} from "../actions/postAction";

function* fetchPosts() {
    try {
        const posts = yield call(fetchPostRequest);
        yield put(postRequestSuccess(posts));
    } catch (error) {
        yield put(postRequestFailed());
    }
}

export { fetchPosts };
