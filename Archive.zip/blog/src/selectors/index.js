const getPosts = (state) => state.postReducer;

export { getPosts };
