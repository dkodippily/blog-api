import React from "react";
import { BlogContainer } from "./components/BlogContainer";
function App() {
  return (
    <div className="App">
     <BlogContainer/>
    </div>
  );
}

export default App;
