import { apiRequest } from "../helpers/api";

const fetchPostRequest = () => {
  return apiRequest({
    method: "GET",
    //url: "https://jsonplaceholder.typicode.com/posts",
    url: "http://localhost:8080/api/posts",
  });
};
// url: "http://localhost:8080/api/posts",

export { fetchPostRequest };
