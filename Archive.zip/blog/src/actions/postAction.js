const postRequest = () => {
  return {
    type: "POST_REQUEST",
  };
};

const postRequestSuccess = (posts) => {
  return {
    type: "POST_REQUEST_SUCCESS",
    posts: posts,
  };
};

const postRequestFailed = () => {
  return {
    type: "POST_REQUEST_FAILED",
  };
};

export { postRequest, postRequestSuccess, postRequestFailed };
