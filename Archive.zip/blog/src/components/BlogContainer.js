import  { Spin,message } from "antd";
import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { postRequest } from "../actions/postAction";
import { getPosts } from "../selectors";
import { Posts } from "./Posts";

const BlogContainer = () => {

    const dispatch = useDispatch();

    const {posts, isPostsFetching,isPostsFetchingFailed}  = useSelector(getPosts);


    useEffect(() => {
        dispatch(postRequest());

    },[dispatch]);

    useEffect(() => {
       if(isPostsFetchingFailed) {
           message.error('Failed to fetch data');

       }

    },[isPostsFetchingFailed]);

    const loadingIcon = isPostsFetching && <Spin />


    return (
        <div>
            {loadingIcon}
           <Posts posts ={posts}/>
        </div>
    )
}
export { BlogContainer }