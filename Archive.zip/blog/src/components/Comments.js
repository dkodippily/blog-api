import { List, Modal } from "antd";
import React from "react";

const Comments = ({comments, isModalVisible, handleOk ,handleCancel}) => {
    return(
        <div>
            <Modal
                title="Comments"
                visible={ isModalVisible }
                onOk={ handleOk }
                onCancel={ handleCancel }
            >
                <List
                    className="comment-list"
                    itemLayout="horizontal"
                    dataSource={ comments }
                    renderItem={comment => (
                        <List.Item>
                            <List.Item.Meta
                                title={ `${comment.name} (${comment.email})` }
                                description={comment.body}
                            />
                        </List.Item>
                    )}
                />
            </Modal>
        </div>
    )
}
export { Comments }