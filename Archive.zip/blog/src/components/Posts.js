import { MessageOutlined, } from '@ant-design/icons';
import { Button, List, Avatar } from 'antd';
import React, { useState } from "react";
import { Comments } from "./Comments";


const Posts = ({ posts }) => {
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [comments, setComments] = useState(null);

    const showModal = (postId) => {
        const filteredPosts = posts.filter(post => post.id === postId);
        const commentsArray = filteredPosts.map((item) => item.comments);

        setComments(commentsArray[0]);

        setIsModalVisible(true);
    };

    const handleOk = () => {
        setIsModalVisible(false);
    };

    const handleCancel = () => {
        setIsModalVisible(false);
    };

    const IconText = ({ text, handler, postItem }) => {
        return (
            <Button
                type="link"
                onClick={ () => handler(postItem.id) }>
                { text }
            </Button>)
    }

    return (
        <div>
            <List
                itemLayout="vertical"
                size="large"
                pagination={ {
                    onChange: page => {

                    },
                    pageSize: 10,
                } }
                dataSource={ posts }
                renderItem={ item => (
                    <List.Item
                        actions={ [
                            <IconText icon={ MessageOutlined }
                                      text="Comments"
                                      key="list-vertical-message"
                                      postItem={ item }
                                      handler={ showModal }/>,
                        ] }>
                        <List.Item.Meta
                            avatar={ <Avatar src="https://picsum.photos/200/300"/> }
                            title={ <a href="https://ant.design">{ item.title }</a> }
                            description= {item.body}
                        />
                    </List.Item>
                ) }
            />

            <Comments comments={comments}
                      handleCancel={handleCancel}
                      handleOk={handleOk}
                      isModalVisible={isModalVisible}/>
        </div>

    )
}
export { Posts }