const initialState = {
    posts: [],
    isPostsFetching: false,
    isPostsFetchingFailed: false,
};

const postReducer = (state = initialState, action) => {

    switch (action.type) {
        case "POST_REQUEST" :
            return {
                ...state,
                isPostsFetching: true,
                isPostsFetchingFailed: false
            }

        case "POST_REQUEST_SUCCESS":
            return {
                ...state,
                posts: action.posts,
                isPostsFetching: false
            }
        case "POST_REQUEST_FAILED":
            return {
                ...state,
                isPostsFetching: false,
                isPostsFetchingFailed: true

            }
        default:
            return state;
    }
}
export {postReducer}