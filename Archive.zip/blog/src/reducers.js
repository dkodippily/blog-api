import { combineReducers } from "redux";
import { postReducer } from "./reducers/postReducer";

const reducers = combineReducers(
    {
        postReducer: postReducer,
    }
);

export { reducers }