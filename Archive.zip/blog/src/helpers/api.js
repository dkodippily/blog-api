import axios from 'axios';

const apiRequest = async (config) => {
    const { data } = await axios(config);
    return data;
};
export {apiRequest}