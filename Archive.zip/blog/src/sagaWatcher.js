import { all, takeLatest } from "redux-saga/effects";
import { fetchPosts } from "./sagas/postSaga";

export function* sagaWatcher() {
    yield all([
        yield takeLatest('POST_REQUEST', fetchPosts),
    ]);
}